(function(){
	
	angular
		.module('insultApp', []);	
})();
